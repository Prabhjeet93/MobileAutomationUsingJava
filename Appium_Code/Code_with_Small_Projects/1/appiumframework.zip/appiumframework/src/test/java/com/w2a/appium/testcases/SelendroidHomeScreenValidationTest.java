package com.w2a.appium.testcases;

import java.io.IOException;

import io.appium.java_client.android.AndroidDriver;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.w2a.appium.base.TestBase;
import com.w2a.appium.screens.nativeapp.SelendroidHomeScreen;
import com.w2a.appium.screens.nativeapp.WebViewInteractionScreen;
import com.w2a.appium.utils.CommonUtils;

public class SelendroidHomeScreenValidationTest extends TestBase{

	
	
	
	@Test
	public void validateHomeScreenTest(){
		
		homeScreen = new SelendroidHomeScreen(driver);
		homeScreen.typeData("Hi Appium");
		homeScreen.validateTextView();
		homeScreen.startWebView();
	
		
	}



}
