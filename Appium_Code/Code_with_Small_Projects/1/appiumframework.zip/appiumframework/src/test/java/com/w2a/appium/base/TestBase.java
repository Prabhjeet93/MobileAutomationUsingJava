package com.w2a.appium.base;

import java.io.IOException;

import io.appium.java_client.android.AndroidDriver;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import com.w2a.appium.screens.nativeapp.SelendroidHomeScreen;
import com.w2a.appium.screens.nativeapp.WebViewInteractionScreen;
import com.w2a.appium.utils.AppiumServer;
import com.w2a.appium.utils.CommonUtils;

public class TestBase {
	

	public static AndroidDriver driver;
	public SelendroidHomeScreen homeScreen;
	public WebViewInteractionScreen webview;
	
	@BeforeSuite
	public void setUp() throws IOException, InterruptedException{
		
		if(driver==null){
	
		AppiumServer.stop();
		AppiumServer.start();
		CommonUtils.loadConfigProp("selendroidtestapp.properties");
		CommonUtils.setCapabilities();
		driver = CommonUtils.getDriver();
		}
		
	}
	
	@AfterSuite
	public void tearDown() throws IOException{
		
		driver.quit();
		AppiumServer.stop();
		
	}

}
