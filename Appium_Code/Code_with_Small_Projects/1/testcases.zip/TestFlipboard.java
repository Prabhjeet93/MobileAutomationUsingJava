package testcases;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.AndroidMobileCapabilityType;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServiceBuilder;
import io.appium.java_client.service.local.flags.GeneralServerFlag;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;

public class TestFlipboard {
	
	
	
	
	
	public static AndroidDriver<MobileElement> driver;
	
	
	
	
	
	
	
	

	public static void main(String[] args) throws MalformedURLException, InterruptedException {


		AppiumDriverLocalService service = AppiumDriverLocalService.buildService(
				new AppiumServiceBuilder().usingDriverExecutable(new File("C:\\Program Files\\nodejs\\node.exe"))
				.withAppiumJS(new File("C:\\Users\\way2automation\\AppData\\Local\\Programs\\Appium\\resources\\app\\node_modules\\appium\\build\\lib\\main.js"))
				.withLogFile(new File(System.getProperty("user.dir")+"\\src\\test\\resources\\logs\\log.txt"))
				.withArgument(GeneralServerFlag.LOCAL_TIMEZONE));
				service.start();
				
				
				
		DesiredCapabilities capabilities = new 	DesiredCapabilities();
		capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "Android");
	
		
		capabilities.setCapability(AndroidMobileCapabilityType.APP_PACKAGE, "flipboard.app");

		capabilities.setCapability(AndroidMobileCapabilityType.APP_ACTIVITY, "flipboard.activities.LaunchActivityAlias");
		
	
		
		
		
		
		
		driver = new AndroidDriver<MobileElement>(new URL("http://127.0.0.1:4723/wd/hub"),capabilities);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		driver.findElement(By.id("flipboard.app:id/first_launch_cover_continue")).click();
		
		driver.findElements(By.id("flipboard.app:id/topic_picker_topic_row_topic_tag")).get(0).click();
		
		driver.findElements(By.id("flipboard.app:id/topic_picker_topic_row_topic_tag")).get(1).click();
		
		
		driver.findElements(By.id("flipboard.app:id/topic_picker_topic_row_topic_tag")).get(2).click();
		
		driver.findElement(By.id("flipboard.app:id/topic_picker_continue_button")).click();
		driver.findElement(By.id("flipboard.app:id/account_login_buttons_skip")).click();
		
		
		Thread.sleep(2000);
		
		ScrollUtil.scrollUp(2,driver);
		
		Thread.sleep(2000);
		
		ScrollUtil.scrollDown(1,driver);
		
	
		Thread.sleep(5000);
		driver.quit();
				
		service.stop();

	}

}
