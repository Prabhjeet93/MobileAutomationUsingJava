package testcases;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.AndroidMobileCapabilityType;
import io.appium.java_client.remote.MobileCapabilityType;

public class ScrollContactsTest {
	
	
	public static AndroidDriver<WebElement> driver;

	public static void main(String[] args) throws MalformedURLException, InterruptedException {

		DesiredCapabilities capabilities = new DesiredCapabilities();

		capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "android");

		capabilities.setCapability(AndroidMobileCapabilityType.APP_PACKAGE, "com.android.contacts");

		capabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, "uiautomator1");

		
		
		capabilities.setCapability(AndroidMobileCapabilityType.APP_ACTIVITY,
				"com.android.contacts.DialtactsContactsEntryActivity");

		
		driver = new AndroidDriver<WebElement>(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		ScrollUtil.scrollToTextByAndroidUIAutomator("Akash", driver).click();
		
		
		Thread.sleep(3000);

		driver.quit();
	}

}
