package steps;

import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;

import base.TestBase;
import io.cucumber.core.api.Scenario;
import io.cucumber.java.After;
import io.cucumber.java.Before;

public class FlipboardHooks extends TestBase {
	
	

}
